;(function ($, ajaxUrl) {


    $(document).ready(function () {
        var frame,
            media = window.wp.media,
            $container = $('#team_metabox'),
            $uploadButton = $('#aboutpage_upload_btn'),
            $containerBody = $('.team_metabox_body'),
            $initialPhotos = $('.photo'),
            postId = $container.data('post-id');

        $uploadButton.on('click', onUploadButtonClick);
        $initialPhotos.find('.remove-photo').on('click', removePhoto);


        function onUploadButtonClick(e) {
            e.preventDefault();

            if (frame) {
                frame.open();
            } else {
                frame = media({
                    title: 'Select images to use',
                    multiple: true,
                    button: {
                        text: 'Select',
                    }
                });
            }

            frame.on('select', onAttachmentsSelected);
        }

        function onAttachmentsSelected() {
            var attachments = frame.state().get('selection').toJSON();

            $(attachments).each(drawAttachmentPreview);

            $.post(ajaxUrl, {
                action: 'aboutUs.attach',
                attachments: attachments,
                post_id: postId,
            }).done(function (response) {
                if (!response.success) {
                    alert(response.message);

                    return;
                }
            });
        }

        function removePhoto() {
            var $photo = $(this).parents('.photo');

            if (confirm('Are you sure?')) {

                $.post(ajaxUrl, {
                    action: 'aboutUs.remove',
                    post_id: postId,
                    attachment_id: $photo.data('attachment-id')
                }).done(function (response) {
                    if (!response.success) {
                        alert(response.message);

                        return;
                    }

                    $photo.remove();
                });
            }

            return false;
        }

        function drawAttachmentPreview(index, attachment) {
            var $container = $('<div/>', { class: 'photo' }),
                $photo = $('<img/>', { src: attachment.sizes.thumbnail.url }),
                $cross = $('</a>', { class: 'remove-photo' }).html('&times;').on('click', removePhoto);

            $container.append($cross).append($photo).appendTo($containerBody);
        }
    });

}(window.jQuery, window.ajaxurl));
